﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gameManager : MonoBehaviour {

	public float moveSpeed = 1.0f;
	public Vector3 moveVector;
}
